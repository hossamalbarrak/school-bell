# موارد تطبيق جرس المدرسة

## الملفات الجاهزة
انسخ مجلد `app/src/main/res/` إلى مجلد الموارد المناظر في مشروعك، مع دمج المجلدات الموجودة وعدم حذف بقية الموارد.

- النغمة: `raw/bell.m4a` — استُخرج مسار AAC الصوتي من ملف MP4 دون إعادة ترميز أو تغيير الصوت. اسم مورد Android هو `R.raw.bell`.
- الأيقونة: `mipmap-*/ic_launcher.png` و`ic_launcher_round.png` — نسخ بأحجام Android من الأيقونة التي أرسلتها.
- نسخة الأيقونة الأصلية محفوظة في `drawable-nodpi/ic_launcher_original.png`.

## إعداد الاسم والأيقونة في AndroidManifest.xml
داخل عنصر `<application ...>` اجعل الإعدادات تتضمن:

```xml
android:label="جرس المدرسة"
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher_round"
```

## ترويسة AndroidManifest.xml لخدمة أمامية على Android 14+
أضف الصلاحيات التالية أعلى `<application>` مع الإبقاء على بقية الصلاحيات الموجودة:

```xml
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

عدّل تعريف الخدمة الموجود داخل `<application>` إلى:

```xml
<service
    android:name=".BellService"
    android:exported="false"
    android:foregroundServiceType="specialUse">
    <property
        android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
        android:value="تشغيل خدمة جرس المدرسة المجدولة وإظهار إشعار دائم بحالة التشغيل" />
</service>
```

## استخدام النغمة
في `AlarmReceiver.java` استخدم المورد `R.raw.bell` بدل البحث عن رابط أو تنزيله:

```java
MediaPlayer mp = MediaPlayer.create(ctx, R.raw.bell);
if (mp != null) mp.start();
```

لا تضع خطوة `curl` لتنزيل صوت بديل في GitHub Actions، كيلا تستبدل النغمة المرفقة.

## تشغيل الإشعار الدائم
في `MainActivity.java` بدّل `startService(new Intent(this,BellService.class));` إلى:

```java
Intent serviceIntent = new Intent(this, BellService.class);
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
    startForegroundService(serviceIntent);
} else {
    startService(serviceIntent);
}
```

في `MainActivity.java` أضف الاستيرادين التاليين:

```java
import android.Manifest;
import android.content.pm.PackageManager;
```

واستبدل استدعاء `startService(...)` الموجود في `onCreate` بطلب الإذن وتشغيل الخدمة:

```java
if (Build.VERSION.SDK_INT >= 33 &&
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
}
startBellService();
```

ثم أضف هذه الدالة داخل `MainActivity`:

```java
private void startBellService() {
    Intent serviceIntent = new Intent(this, BellService.class);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        startForegroundService(serviceIntent);
    } else {
        startService(serviceIntent);
    }
}
```

بهذا يظهر إشعار دائم في درج الإشعارات ما دام المستخدم قد منح الإذن. أبقِ قناة الإشعار ذات الأهمية المنخفضة في `BellService` كي يظهر إشعار مستمر دون إزعاج. إذا رفض المستخدم إذن الإشعارات، فقد لا يظهر في الدرج رغم تشغيل الخدمة.
